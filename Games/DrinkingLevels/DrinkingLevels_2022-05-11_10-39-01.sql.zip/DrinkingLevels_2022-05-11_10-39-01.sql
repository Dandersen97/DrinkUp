-- MariaDB dump 10.19  Distrib 10.5.10-MariaDB, for Win64 (AMD64)
--
-- Host: a2nlmysql23plsk.secureserver.net    Database: DrinkingLevels
-- ------------------------------------------------------
-- Server version	5.5.51-38.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Achievements`
--

DROP TABLE IF EXISTS `Achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Achievements` (
  `AchievementId` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(50) NOT NULL,
  PRIMARY KEY (`AchievementId`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Achievements`
--

LOCK TABLES `Achievements` WRITE;
/*!40000 ALTER TABLE `Achievements` DISABLE KEYS */;
INSERT INTO `Achievements` VALUES (0,'Hidden'),(1,'The Basics'),(2,'The Keys'),(3,'Shots'),(4,'Mikes Hard'),(5,'Twisted Tea'),(6,'Christmas');
/*!40000 ALTER TABLE `Achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `DRINK_CHART`
--

DROP TABLE IF EXISTS `DRINK_CHART`;
/*!50001 DROP VIEW IF EXISTS `DRINK_CHART`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `DRINK_CHART` (
  `DrinkID` tinyint NOT NULL,
  `DrinkName` tinyint NOT NULL,
  `DrinkRecipe` tinyint NOT NULL,
  `ABV` tinyint NOT NULL,
  `Type` tinyint NOT NULL,
  `12oz` tinyint NOT NULL,
  `16oz` tinyint NOT NULL,
  `Shot` tinyint NOT NULL,
  `5oz` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `Drinks`
--

DROP TABLE IF EXISTS `Drinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Drinks` (
  `DrinkID` int(11) NOT NULL AUTO_INCREMENT,
  `DrinkName` mediumtext NOT NULL,
  `DrinkRecipe` mediumtext NOT NULL,
  `ABV` decimal(10,0) NOT NULL,
  `Type` varchar(255) NOT NULL,
  PRIMARY KEY (`DrinkID`)
) ENGINE=MyISAM AUTO_INCREMENT=1647115420 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Drinks`
--

LOCK TABLES `Drinks` WRITE;
/*!40000 ALTER TABLE `Drinks` DISABLE KEYS */;
INSERT INTO `Drinks` VALUES (0,'DEFAULT','DEFAULT',0,''),(1,'Jack and Coke','1 Can Coke 1 Shot Jack Daniels',3,'MIXER'),(2,'Jack and Coke Double','1 can coke 2 shots Jack Daniels',6,'MIXER'),(3,'Fiery Peach','1 Can Sprite 1pt Peach Schnapps 1pt Fireball (Cinnamon Whiskey)',5,'MIXER'),(4,'Flaming Peach','1/2pt Peach Schnapps 1/2pt Fireball (Cinnamon Whiskey) Lightly layer Everclear on top layer Set aflame BLOW OUT BEFORE DRINKING',33,'SHOT'),(5,'Pickleback','1 Shot Whiskey 1 Shot Pickle Juice',40,'SHOT'),(6,'Whiskey Pickles','Empty juice from jar of pickles\nFill jar with whiskey\nLet soak for at least 24hrs',0,'Food'),(7,'Cococoke','1 Can Coke\n1pt Coconut Rum',0,'MIXER'),(8,'Keystone','1 12oz Can Keystone',4,'CAN'),(9,'Keystone 16oz','1 16oz Can Keystone',5,'CAN'),(10,'Shot of Evan Williams','1 Shot Evan Williams',43,'SHOT'),(11,'Shot of Jack Daniels','1 Shot Jack Daniels',40,'SHOT'),(12,'Shot of Kraken','1 Shot Kraken Rum',47,'SHOT'),(13,'Shot of Kinky','1 Shot Kinky',17,'SHOT'),(14,'Smirnoff Red White and Blue Can','1 Can Smirnoff Red White and Blue',5,'CAN'),(15,'Smirnoff Red White and Blue Bottle','1 Bottle Smirnoff Red White and Blue',5,'BOTTLE'),(16,'Mikes Hard Lemonade','1 Bottle Mikes Hard Lemonade',5,'BOTTLE'),(17,'Mikes Hard Cherry Lemonade','1 Bottle Mikes Hard Cherry Lemonade',5,'BOTTLE'),(18,'Angry Orchard Hard Cider','1 Bottle Angry Orchard Hard Cider',5,'BOTTLE'),(19,'Ciderboys','1 Bottle Ciderboys',5,'BOTTLE'),(20,'Strongbow','1 Can Strongbow',5,'CAN'),(1635968596,'Pirate Nancy','Light beer, pineapple juice, coconut rum',7,'MIXER'),(1635202644,'Rebel Hard Tea Sweet Tea','1 can Rebel Hard Sweet Tea Sweet Tea',5,'CAN'),(1635203944,'Rebel Hard Tea Half & half','1 can Rebel Hard Half & half tea',5,'CAN'),(1635272194,'Pabst blue ribbon hard coffee- Mocha','Can of Pabst blue ribbon hard coffee- mocha',5,'CAN'),(1635285959,'New Amsterdam Watermelon','One shot',35,'SHOT'),(1635289804,'Coors light','Straight',4,'CAN'),(1635291609,'Left hand moscow mule','Pale ale',6,'CAN'),(1635371847,'WCS juice and BC rum','Juice and rum',5,'MIXER'),(1635374525,'Pabst blue ribbon hard coffee- Salted caramel','Can of Pabst blue ribbon hard coffee- mocha',5,'CAN'),(1635444208,'Dave and Dani - Apple Pie','Bottle of Dave and Dani apple pie',6,'BOTTLE'),(1635453237,'Jack and Coke Triple with Pineapple Juice','Can of coke with 3 shots of Jack Daniels and pineapple juice',12,'MIXER'),(1635457394,'Sprite + a lot','Can of sprite plus many other liquors ',10,'MIXER'),(1635467100,'Blanton’s single barrel bourbon','Bourbon',50,'SHOT'),(1635540324,'Pabst blue ribbon hard coffee- Original','Can of Pabst blue ribbon hard coffee- org.',5,'CAN'),(1635549338,'Bohemia','One bottle Bohemia Mexican Pilsner ',5,'BOTTLE'),(1635549818,'Watermelon Margarita','At restaurant ',20,'MIXER'),(1635617654,'Dr McGillicuddys - Apple Pie','1 shot mcgillicuddys apple pie',21,'SHOT'),(1635619315,'Keke mountain dew','Keke and Mountain Dew ',5,'MIXER'),(1635619531,'Coke Apple Pie','Can of coke and shot of mcgillicuddys apple pie',4,'MIXER'),(1635626467,'Malibu','Can',5,'CAN'),(1635626572,'Fuck It','Just give my xp. A mix of random things at inconsistent ratios',5,'MIXER'),(1635628197,'KEKE','One shot of KEKE',15,'SHOT'),(1635629150,'Sex on the beach','Shot of sex on the beach',20,'SHOT'),(1635629981,'Rum Chata peppermint bark','One shot of rum chata peppermint bark ',14,'SHOT'),(1635630116,'Rum chata peppermint bark','One shot of rum chata peppermint bark',14,'SHOT'),(1635632437,'Michelob Ultra','1 can Michelob ultra',4,'CAN'),(1635638102,'Malibu splash','Can',5,'CAN'),(1635639255,'Fun mix','Black cherry whiskey and Dr Pepper ',5,'MIXER'),(1635644198,'Malibu splash pineapple & coconut','One can',5,'CAN'),(1635980369,'Life Coach Lager','The Piss of God',5,'CAN'),(1635983515,'Crown Royal Peach','Shot of Crown Royal Peach',35,'SHOT'),(1636069233,'Fuzzy Navel','Orange juice and peach schnapps',3,'MIXER'),(1636142526,'Gentleman Jack on the rocks','Gentleman Jack plus ice cubes',40,'MIXER'),(1636142748,'Pabst blue ribbon hard coffee- Slightly sweet','One can of Pabst blue ribbon hard coffee- Slightly sweet',5,'CAN'),(1636165827,'Gin/dr.pepper','Gin and dr.pepper',5,'MIXER'),(1636222039,'Mimosa','OJ and champagne- blue moose',2,'MIXER'),(1636229331,'Dr McGillicuddys - Root Beer','1 shot mcgillicuddys root beer',21,'SHOT'),(1636229747,'American Honey','1 shot wild turkey American honey',36,'SHOT'),(1636236626,'Bottle cap- root beer','Sprite, two shots of Mcgillicuddys root beer',4,'MIXER'),(1636253492,'Bud Light; Chelada, Clamato','Can',4,'CAN'),(1636324151,'Seagrams escapes: Jamaican me happy','Can',3,'CAN'),(1636337047,'Kamora: coffee flavored ','A shot of kamora',20,'SHOT'),(1636342349,'Hiram Walker: peppermint schnapps','A shot',30,'SHOT'),(1642034000,'99 - Butterscotch','1 shot 99 proof',49,'SHOT'),(1636591606,'Coke and Honey Whiskey','Coke and Wild turkey honey whiskey',3,'MIXER'),(1636597491,'Sipping Pretty','Beer',5,'CAN'),(1636674451,'Smirnoff Vodka','One shot',40,'SHOT'),(1636767091,'Melted Root Beer Float','1 can cream soda with 1 shot Dr McGillicuddys Root Beer',2,'MIXER'),(1636771163,'Red beer','Tomato juice, can of michelob',3,'MIXER'),(1636830877,'VSL','Vodka sprite and lemonade ',3,'MIXER'),(1637021441,'The Captain vs The Kraken','1 shot captain Morgan and 1 shot kraken black rum with a coke',6,'MIXER'),(1637105076,'Bog Monster','Beer',7,'CAN'),(1637105169,'Stuff of Legend','Boulevard Brewing Co',13,'CAN'),(1637107789,'Devils Throne','Beer',8,'CAN'),(1637202988,'Gentleman Jack','One shot',35,'SHOT'),(1637366526,'Kentucky Mule','Wild Turkey, lime juice, ginger beer',6,'MIXER'),(1637366597,'Long island iced tea','Long Island ice tea',6,'MIXER'),(1637374429,'Konza Kiss','Unknown',0,'MIXER'),(1637374652,'Fruity Fizz','Vodka, muddled lemon, lime, orange, blueberries',0,'MIXER'),(1637466434,'Sex on the beach/mountain dew','Sex on the beach, mountain dew',5,'MIXER'),(1637538870,'UV vodka blue raspberry','Vodka shot',30,'SHOT'),(1637718809,'Coke & rum','Black cherry rum and coke',2,'MIXER'),(1637805342,'Rum and Coke','Rum and Coke',3,'MIXER'),(1637805389,'Pinacolafa','Pinacolada',3,'MIXER'),(1637891521,'Dr. Pepper/ whiskey','Whiskey and dr.pepper',5,'MIXER'),(1637976950,'Brady’s Irish cream','A shot of this',17,'SHOT'),(1637985079,'Boones fuzzy navel ','A bottle of this',6,'BOTTLE'),(1638414675,'Cherry Poppins','1 can of cherry poppins',4,'BOTTLE'),(1639010604,'Smirnoff vodka','One shot of vodka ',40,'SHOT'),(1640376534,'Crook & marker','Raspberry lemonade ',4,'CAN'),(1640380460,'Smirnoff seltzer','Spicy tamarind',5,'CAN'),(1640380696,'Crook and Marker Lemonadr','1 can we f Crook and Marker lemonade',4,'CAN'),(1640387941,'Samuel adams winter lager','Beer',6,'BOTTLE'),(1640389011,'Samuel adams holiday white ale','Beer',6,'BOTTLE'),(1640389886,'Dr. Pepper /vodka','Dr Pepper vodka',5,'MIXER'),(1640391638,'Samuel adams old fezziwig','Beer',6,'BOTTLE'),(1640439796,'Irish Coffee','Coffee and Irish cream',2,'MIXER'),(1640449947,'Coffee and Kahlua','Coffee and Kahlua (X1 shots) ',20,'MIXER'),(1640457646,'Crown Royal','1 shot crown royal',40,'SHOT'),(1640457721,'Viaka vodka','One shot of vodka',40,'SHOT'),(1640457908,'Chivas Regal 12 year','Love',40,'SHOT'),(1640462346,'Michelob Ultra seltzer','1 can Michelob ultra seltzer',4,'CAN'),(1640466774,'Kahlua','One shot',20,'SHOT'),(1640466918,'Buttershots schnapps','One shot',30,'SHOT'),(1640466921,'Buttershots schnapps','One shot',30,'SHOT'),(1640467195,'Smoky hill: restless summer','Bottle of win',5,'BOTTLE'),(1640474037,'Eagle Rare','1 shot eagle rare',45,'SHOT'),(1640479738,'Samuel adams holiday porter','Beer',6,'BOTTLE'),(1640481863,'Cayman jack moscow mule','One can',6,'CAN'),(1640488966,'Margarita ','One can',6,'CAN'),(1640494034,'Pickle beer','Beer and pickle juice ',3,'MIXER'),(1640632143,'Blueberry Kisses','Tap House porter',7,'CAN'),(1640632228,'Snowball','Water',5,'CAN'),(1643930679,'Stella Artois','One bottle',5,'BOTTLE'),(1644623887,'Truly Strawberry Margarita','1 can',5,'CAN'),(1644626217,'Biskeyrita','Half can beer, half cup margarita mix, 2 shots whisky',4,'MIXER'),(1644631509,'Buffalo Sweat','1 can',5,'CAN'),(1647110168,'Generic Beer','A beer',5,'BOTTLE'),(1647110237,'Good beer','Dick and ball juice.',7,'BOTTLE'),(1647110289,'Liquid marijuana','Liquid marijuana ',3,'MIXER'),(1647110393,'Boulevard Take 7','American saison ale',9,'BOTTLE'),(1647115233,'Sour beer','Beer',5,'CAN'),(1647115419,'KC Bier Co. Dunkel','Munich style brown ale',5,'BOTTLE');
/*!40000 ALTER TABLE `Drinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LevelHistory`
--

DROP TABLE IF EXISTS `LevelHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LevelHistory` (
  `RowID` int(10) NOT NULL AUTO_INCREMENT,
  `UserID` int(10) NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Level` int(10) DEFAULT NULL,
  `UserHistoryID` int(10) DEFAULT NULL,
  `PerkID` int(10) DEFAULT NULL,
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LevelHistory`
--

LOCK TABLES `LevelHistory` WRITE;
/*!40000 ALTER TABLE `LevelHistory` DISABLE KEYS */;
INSERT INTO `LevelHistory` VALUES (1,2,'2021-03-03 14:54:16',1,1,3),(2,2,'2021-03-03 14:54:16',2,3,1);
/*!40000 ALTER TABLE `LevelHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Levels`
--

DROP TABLE IF EXISTS `Levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Levels` (
  `LevelID` int(5) NOT NULL,
  `XpToLevel` int(5) NOT NULL,
  `NextLevel` int(11) NOT NULL,
  `PrevLevel` int(11) NOT NULL,
  PRIMARY KEY (`LevelID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Levels`
--

LOCK TABLES `Levels` WRITE;
/*!40000 ALTER TABLE `Levels` DISABLE KEYS */;
INSERT INTO `Levels` VALUES (0,20,1,0),(1,70,2,0),(2,130,3,1),(3,200,4,2),(4,280,5,3),(5,370,6,4),(6,470,7,5),(7,580,8,6),(8,700,9,7),(9,830,10,8),(10,970,11,9),(11,1120,12,10),(12,1280,13,11),(13,1450,14,12),(14,1630,15,13),(15,1820,16,14),(16,2020,17,15),(17,2230,18,16),(18,2450,19,17),(19,2680,20,18),(20,2920,21,19);
/*!40000 ALTER TABLE `Levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Perks`
--

DROP TABLE IF EXISTS `Perks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Perks` (
  `PerkID` int(5) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` mediumtext NOT NULL,
  PRIMARY KEY (`PerkID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Perks`
--

LOCK TABLES `Perks` WRITE;
/*!40000 ALTER TABLE `Perks` DISABLE KEYS */;
INSERT INTO `Perks` VALUES (1,'2 of 3','You have the indisputable right to redo a challenge you\'ve lost into a best 2 out of 3. Be it a coin flip, rock paper scissors, or russian roulette.'),(2,'Trigger Word','Write down and save a trigger word. When another person says this word TO YOU they must drink. The trigger word cannot a name/nickname.'),(3,'Guess Who','If someone else calls you by the wrong name, make them drink. Drunken slur of your name does not count.'),(4,'Shot Out','You can exclude yourself from an enforced drinking game by taking a shot chosen by the other players. If you\'d like to join the same game later you must take another shot to join back in. Drinking games include but are not limited to Ring of Fire, Jenga, Red Dragon\'s Inn, Shot Roulette, Waterfall, Never Had I Ever.');
/*!40000 ALTER TABLE `Perks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProfilePerks`
--

DROP TABLE IF EXISTS `ProfilePerks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProfilePerks` (
  `RowID` int(10) NOT NULL AUTO_INCREMENT,
  `PerkID` int(5) NOT NULL,
  `ProfileID` int(5) NOT NULL,
  `UserID` int(11) NOT NULL,
  `PerkOption1` varchar(255) NOT NULL,
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProfilePerks`
--

LOCK TABLES `ProfilePerks` WRITE;
/*!40000 ALTER TABLE `ProfilePerks` DISABLE KEYS */;
INSERT INTO `ProfilePerks` VALUES (1,2,1164377982,1,'like'),(2,1,388710208,1,''),(3,1,702978023,2,''),(4,3,7802267,2,'');
/*!40000 ALTER TABLE `ProfilePerks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Profile_Details`
--

DROP TABLE IF EXISTS `Profile_Details`;
/*!50001 DROP VIEW IF EXISTS `Profile_Details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `Profile_Details` (
  `UserID` tinyint NOT NULL,
  `Username` tinyint NOT NULL,
  `ProfileID` tinyint NOT NULL,
  `Name` tinyint NOT NULL,
  `Level` tinyint NOT NULL,
  `XP` tinyint NOT NULL,
  `Description` tinyint NOT NULL,
  `Title` tinyint NOT NULL,
  `XpToLevel` tinyint NOT NULL,
  `Actual_Total_Xp` tinyint NOT NULL,
  `Actual_Total_XpToLevel` tinyint NOT NULL,
  `Template` tinyint NOT NULL,
  `Avatar` tinyint NOT NULL,
  `ActiveTitle` tinyint NOT NULL,
  `UnlockedTitles` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `Profile_History`
--

DROP TABLE IF EXISTS `Profile_History`;
/*!50001 DROP VIEW IF EXISTS `Profile_History`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `Profile_History` (
  `RowID` tinyint NOT NULL,
  `ProfileID` tinyint NOT NULL,
  `DrinkID` tinyint NOT NULL,
  `Name` tinyint NOT NULL,
  `DrinkName` tinyint NOT NULL,
  `DrinkRecipe` tinyint NOT NULL,
  `Type` tinyint NOT NULL,
  `ABV` tinyint NOT NULL,
  `Timestamp` tinyint NOT NULL,
  `Timestamp_Date` tinyint NOT NULL,
  `Rating` tinyint NOT NULL,
  `Notes` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `Profiles`
--

DROP TABLE IF EXISTS `Profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Profiles` (
  `ProfileID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL DEFAULT 'Default',
  `Description` varchar(255) NOT NULL DEFAULT 'Default',
  `Level` int(11) NOT NULL DEFAULT '0',
  `XP` int(11) NOT NULL DEFAULT '0',
  `ActiveTitle` varchar(255) NOT NULL DEFAULT '{0:0}',
  `UnlockedTitles` mediumtext,
  `FriendProfiles` mediumtext,
  `Template` varchar(50) NOT NULL DEFAULT 'Default',
  `Avatar` varchar(100) NOT NULL DEFAULT 'Default',
  PRIMARY KEY (`ProfileID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Profiles`
--

LOCK TABLES `Profiles` WRITE;
/*!40000 ALTER TABLE `Profiles` DISABLE KEYS */;
INSERT INTO `Profiles` VALUES (1632185629,1632185629,'Devon','Everyday All Day',0,0,'{3:1.2.1}','{0:1},{3:1},{3:1.1},{3:1.1.2},{3:1.2},{3:1.2.1},{3:1.2.1.1},{3:2},{{}},{1:1},{1:1.2.3},{1:1.2}','{1633742135},{1632185629},{1635617764},{1634216328},{1635639508},{1636320886},{1635289739}','Default','Default'),(1634159870,1632185629,'CreshJR','Wednesday Game Night',0,0,'{0:1}','{0:1}','{1634159870},{1635286780},{1636481996}','BluePlaid','man1'),(1633742135,1633742135,'Jess','Everyday All Day',0,0,'{0:5}','{0:1},{0:5}','{1632185629},{1635289739},{1635617764},{1635639508},{1634216328}','Default','Default'),(1634216328,1634216328,'Handsies','Everyday All Day',0,0,'{0:1}','{0:1},{0:7}','{1633742135},{1632185629},{1635617764},{1634216328},{1635289739},{1635639508}','Blue','woman3'),(1635286780,1633742135,'PrincessGoomba','Wednesday game night ',0,0,'{0:0}','{0:1},{0:5}','{1634159870},{1636482054},{1636482054},{1636481996}','Default','Default'),(1635289739,1635289739,'Trev','Everyday All Day',0,0,'{0:2}','{0:1},{0:2}','{1632185629},{1633742135},{1635617764},{1635639508},{1634216328}','Default','Default'),(1635360868,1635360868,'Trentontyhill','Everyday All Day',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1635617764,1635617764,'Jc','Everyday All Day',0,0,'{0:3}','{0:1},{0:3}','{1633742135},{1632185629},{1635289739},{1635639508},{1634216328}','Default','Default'),(1635639508,1635639508,'LauraLiquor','Everyday All Day',0,0,'{0:4}','{0:1},{0:4}','{1632185629},{1635289739},{1635617764},{1635639508},{1634216328}','Default','Default'),(1636481952,1636481952,'amechtle','Everyday All Day',0,0,'{0:0}','{0:1},{0:6}',NULL,'Default','Default'),(1636320886,1636320886,'conradic','Everyday All Day',0,0,'{0:0}',NULL,'{1633742135},{1635289739},{1635617764},{1635639508},{1634216328}','Default','Default'),(1636320923,1636320886,'Colton ',' ',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1636481996,1636481952,'amechtle','Wednesday Game Night',0,0,'{0:6}','{0:1},{0:6}','{1635286780},{1634159870}','Default','Default'),(1637373889,1637373889,'Jnbrock','Everyday All Day',0,0,'{0:0}',NULL,'{163218},{1632185629},{1633742135},{1634216328}','Default','Default'),(1640372531,1640372531,'Triple Fister','Everyday All Day',0,0,'{0:0}','{0:1}',NULL,'Default','Default'),(1640372733,1640372531,'Christmas','Christmas',0,0,'{0:0}',NULL,'{1640374271},{1640374647},{1640375236}','Default','Default'),(1640374271,1632185629,'Devon Christmas','Christmas 2021',0,0,'{0:0}','{6:1}','{1640375236},{1640374271},{1640449496},{1640372733},{1640374647},{1640374331}','BluePlaid','woman1'),(1640374279,1632185629,'Devon Christmas','Christmas 2021',0,0,'{0:0}','{1:1.2.3}',NULL,'Default','Default'),(1640374331,1635617764,'Jc','Weeb',0,0,'{0:0}',NULL,'{1640372733},{1640375236},{1640374271},{1640374647}','Default','Default'),(1640374365,1635617764,'Jc','Weeb',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1640374404,1635617764,'Jc','Weeb',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1640374647,1635289739,'Christmas','Christmas tournament ',0,0,'{0:0}',NULL,'{1640374271},{1640375236},{1640372733}','Default','Default'),(1640374657,1635289739,'Christmas','Christmas tournament ',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1640375236,1633742135,'Christmas elf Jess','Christmas drinking',0,0,'{0:0}',NULL,'{1640374271},{1640374647},{1640372733},{1640374331},{1640449496}','Default','Default'),(1640375241,1633742135,'Christmas elf Jess','Christmas drinking',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1640375776,1635617764,'Jc','Weeb',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1640375797,1635617764,'Jc','Weeb',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1640449496,1634216328,'The Pussy','Christmas Pootang',0,0,'{0:0}',NULL,'{1640374331},{1640372733},{1640375236},{1640374647},{1640374271}','Default','Default'),(1640449503,1634216328,'The Pussy','Christmas Pootang',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1647109699,1633742135,'FP - Jess','Drink up mother fucker',0,0,'{0:0}',NULL,'{1647109699},{1647109749},{1647110164},{1647110065},{1647110065},{1647110095}','Default','Default'),(1647109749,1632185629,'Devon Fake Patties','Fake Patties 2022',0,0,'{0:0}',NULL,'{1647109699},{1647110164},{1647110095},{1647110095},{1647110065},{1647110065}','Default','Default'),(1647110004,1647110004,'MJackson','Everyday All Day',0,0,'{0:0}',NULL,NULL,'Default','Default'),(1647110065,1647110065,'J-Rock','Everyday All Day',0,0,'{0:0}',NULL,'{1647110065},{1647109699},{1647110164},{1647110095}','Default','Default'),(1647110095,1647110095,'trentontyhill@gmail.com','Everyday All Day',0,0,'{0:0}',NULL,'{1647110164},{1647109749}','Default','Default');
/*!40000 ALTER TABLE `Profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Titles`
--

DROP TABLE IF EXISTS `Titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Titles` (
  `Category` int(10) NOT NULL,
  `CategoryDesc` varchar(255) NOT NULL,
  `Position` varchar(255) NOT NULL,
  `Title` varchar(3200) NOT NULL,
  `Avatar` varchar(100) DEFAULT NULL,
  `Requirements` varchar(3200) NOT NULL,
  `PreReq` varchar(50) DEFAULT NULL,
  `Image` mediumtext NOT NULL,
  `X` int(11) NOT NULL,
  `Y` int(11) NOT NULL,
  `Width` int(10) NOT NULL DEFAULT '50',
  `Height` int(10) NOT NULL DEFAULT '50',
  UNIQUE KEY `TitleID` (`Category`,`Position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Titles`
--

LOCK TABLES `Titles` WRITE;
/*!40000 ALTER TABLE `Titles` DISABLE KEYS */;
INSERT INTO `Titles` VALUES (0,'Default','0','No Title',NULL,'NONE',NULL,'',200,200,50,50),(1,'The Basics','1','Noob',NULL,'Drink a beverage containing alchohol','','man1',442,297,425,622),(1,'The Basics','1.1','Novice',NULL,'Drink a beverage containing 6% or more ABV','1','cup2',869,428,52,71),(2,'The Keys','1','First Key',NULL,'Drink a Keystone','','imgStarBlank.png',330,200,50,50),(2,'The Keys','1.1','Key Ring',NULL,'Drink 3 Keystones in a single day','1','imgStarBlank.png',390,200,50,50),(2,'The Keys','1.1.1','Keyblade',NULL,'Drink 10 Keystones in a single day','1.1','imgStarBlank.png',450,200,50,50),(2,'The Keys','1.1.1.1','Key Master',NULL,'Drink 20 Keystones in a single day','1.1.1','imgStarBlank.png',510,200,50,50),(2,'The Keys','1.2','Gatekeeper',NULL,'Drink 100 Keystones in a lifetime','1','imgStarBlank.png',570,200,50,50),(3,'Shots','1','Pistol',NULL,'Take a single shot','','imgShot.png',550,320,50,50),(3,'Shots','1.1','Double Barrel',NULL,'Take a double shot (2 shots does not count)','1','imgStarBlank.png',370,420,50,50),(3,'Shots','1.1.1','Quick Reload',NULL,'Take 2 shots in rapid succession (A shot and chaser do not count)','1.1','imgShot2.png',200,250,50,50),(3,'Shots','1.1.2','Magnum',NULL,'Take a triple shot (3 shots does not count)','1.1','imgStarBlank.png',160,360,50,50),(3,'Shots','1.2','Eagle Eye',NULL,'Take 3 shots in a single day','1','imgStarBlank.png',290,200,50,50),(3,'Shots','1.2.1','Sharp Shooter',NULL,'Take 5 shots in a single day','1.2','imgStarBlank.png',400,100,50,50),(3,'Shots','1.2.1.1','Sniper',NULL,'Take 10 shots in a single day','1.2.1','imgStarBlank.png',560,60,50,50),(3,'Shots','1.2.1.1.1','Elite Sniper',NULL,'Take 15 shots in a single day','1.2.1.1','imgStarBlank.png',780,100,50,50),(3,'Shots','1.2.1.1.1.1','Motherfuckin Rambo',NULL,'Take 21 shots in a single day','1.2.1.1.1','imgStarBlank.png',560,200,50,50),(3,'Shots','2','The Lover',NULL,'Shot through the heart! And youre to blame. Darlin you took a shot of Tequila Rose','','imgStarBlank.png',1270,270,50,50),(3,'Shots','2.1','French Kisser',NULL,'Take a French Kisser Shot (see drink menu)','2','imgStarBlank.png',1030,450,50,50),(1,'The Basics','1.1.1','Amateur',NULL,'Drink a beverage containing 35% or more ABV','1','cup3',1262,434,51,70),(1,'The Basics','1.2.1','Liquored Up',NULL,'Have a drink from each of the 6 main liqour groups (Vodka, Rum, Whiskey, Brandy, Gin, Tequilla)','1.2','bottle4',1130,318,162,130),(1,'The Basics','1.2.2','Confused',NULL,'Have a LIQUER drink with a base from each of the 6 main liqour groups (Vodka, Rum, Whiskey, Brandy, Gin, Tequilla)','1.2','bottle1',872,273,63,113),(1,'The Basics','1.3','The Baby',NULL,'Drink a beverage containing alchohol from a bottle','1','bottle1',871,128,63,113),(1,'The Basics','1.4','Placeholder',NULL,'Coming soon','1','bottle2',941,136,46,103),(3,'Shots','1.2.1.1.2.1','Rare Candy',NULL,'Take a Rare Candy shot (see drink menu)','1.2.1.1.2','imgStarBlank.png',160,70,50,50),(3,'Shots','3','The Buyer',NULL,'Purchase a shot glass on any kind','','imgStarBlank.png',1500,800,50,50),(3,'Shots','3.1','The Simple',NULL,'Purchase a blank, standard, glass shot glass','3','imgStarBlank.png',1400,750,50,50),(3,'Shots','3.1.1','The Designer',NULL,'Purchase a shot glass with any design on it','3.1','imgStarBlank.png',1320,830,50,50),(3,'Shots','3.1.2','The Novel',NULL,'Purchase a novelty, non-conforming shot glass. Common styles include skulls, pot leaves, or body parts','3.1','imgStarBlank.png',1300,700,50,50),(3,'Shots','3.2','The Gatherer',NULL,'Purchase 5+ shot glasses in a lifetime','3','imgStarBlank.png',1670,870,50,50),(3,'Shots','3.2.1','The Collector',NULL,'Purchase 15+ shot glasses in a lifetime','3.2','imgStarBlank.png',1770,760,50,50),(3,'Shots','3.2.1.1','The Hoarder',NULL,'Purchase 21+ shot glasses in a lifetime','3.2.1','imgStarBlank.png',1850,1000,50,50),(3,'Shots','3.3','The Sibling',NULL,'Purchase 2+ shot glasses at the same time','3','imgStarBlank.png',1620,520,50,50),(4,'Mike\'s Hard','1','Getting Hard',NULL,'Drink a Mikes Hard drink','','imgStarBlank.png',100,500,50,50),(4,'Mike\'s Hard','1.1','Getting Harder',NULL,'Drink 5 Mikes Hard in a single day','1','imgStarBlank.png',100,550,50,50),(4,'Mike\'s Hard','1.1.1','Getting Even Harder',NULL,'Drink 10 Mikes Hard in a single day','1.1','imgStarBlank.png',100,600,50,50),(4,'Mike\'s Hard','1.1.1.1','Getting Really Hard',NULL,'Drink 20 Mikes Hard in a single day','1.1.1','imgStarBlank.png',100,650,50,50),(4,'Mike\'s Hard','1.1.1.1.1','The Hard',NULL,'Drink 100 Mikes Hard in a lifetime','1.1.1.1','imgStarBlank.png',100,700,50,50),(4,'Mike\'s Hard','1.2','Going Soft',NULL,'Drink 2 different Mikes Hard drinks in a single day','1','imgStarBlank.png',100,750,50,50),(4,'Mike\'s Hard','1.2.2','Getting Softer',NULL,'Mix 2 different Mikes Hard drinks and drink the mixture','1.2','imgStarBlank.png',100,800,50,50),(4,'Mike\'s Hard','1.2.1','Big Ol Softy',NULL,'Drink 6 different Mikes Hard drinks in a single day','1.2','imgStarBlank.png',100,850,50,50),(4,'Mike\'s Hard','2','Tent Pitcher',NULL,'Drink a Mikes Hard while in a tent','','imgStarBlank.png',100,900,50,50),(5,'Twisted Tea','1','Tea Time',NULL,'Drink a Twisted Tea','','imgStarBlank.png',300,500,50,50),(5,'Twisted Tea','1.1','Mr. Tea',NULL,'Drink 5 Twisted Teas in a single day','1','imgStarBlank.png',300,550,50,50),(5,'Twisted Tea','1.1.1','Twisted Sister',NULL,'Drink 12 Twisted Teas in a single day','1.1','imgStarBlank.png',300,600,50,50),(3,'Shots','1.2.1.1.2','Hot Shot',NULL,'Take a shot that has been lit aflame (BLOW OUT BEFORE TAKING)','1.2.1.1','imgStarBlank.png',320,30,50,50),(0,'Default','1','Alpha Tester',NULL,'Specialty title for being an Alpha Tester',NULL,'',200,250,50,50),(0,'DEFAULT','2','Eldergeist',NULL,'Specialty title for being an Alpha Tester',NULL,'',200,300,50,50),(0,'','3','The Weeb',NULL,'Specialty title for being an Alpha Tester',NULL,'',200,350,50,50),(0,'','4','No Shit Taker',NULL,'Specialty title for being an Alpha Tester',NULL,'',200,400,50,50),(0,'','5','The Baddest Bitch',NULL,'Specialty title for being an Alpha Tester',NULL,'',200,450,50,50),(0,'','6','Vulpixxx',NULL,'Specialty title for being an Alpha Tester',NULL,'',200,500,50,50),(6,'Christmas','1','Most Wonderful Time','Christmas 2021','Have an alcoholic drink in December','','bauble1.svg',1150,800,50,50),(6,'Christmas','2','Gingerbread Man',NULL,'Drink a ginger beer','','bauble2.svg',880,400,50,50),(1,'','1.5','Bartender',NULL,'Make a drink for someone else','1','man2',1097,75,315,443),(1,'','1.6','The Whiny',NULL,'Have a glass of wine','1','bottle6',600,200,50,50),(0,'','7','The Droid',NULL,'Specialty title for being an Alpha tester',NULL,'',200,550,50,50);
/*!40000 ALTER TABLE `Titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserHistory`
--

DROP TABLE IF EXISTS `UserHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserHistory` (
  `RowID` int(10) NOT NULL AUTO_INCREMENT,
  `DrinkID` int(11) NOT NULL,
  `UserID` int(10) NOT NULL,
  `ProfileID` int(11) NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Rating` int(2) DEFAULT '0',
  `Notes` mediumtext,
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM AUTO_INCREMENT=420 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserHistory`
--

LOCK TABLES `UserHistory` WRITE;
/*!40000 ALTER TABLE `UserHistory` DISABLE KEYS */;
INSERT INTO `UserHistory` VALUES (194,3,1633742135,1633742135,'2021-11-10 01:09:07',6,''),(41,1635285959,1633742135,1633742135,'2021-10-26 22:05:59',8,'Gets me drunk '),(40,10,1632185629,1632185629,'2021-10-26 22:04:21',8,'Great for cheap whiskey '),(38,1635272194,1633742135,1633742135,'2021-10-26 18:16:34',4,'Weird taste'),(45,1635285959,1633742135,1633742135,'2021-10-26 22:59:25',8,''),(44,1635285959,1633742135,1633742135,'2021-10-26 22:25:36',8,''),(43,1635285959,1633742135,1633742135,'2021-10-26 22:16:59',8,''),(36,1635202644,1632185629,1632185629,'2021-10-25 22:57:24',6,'Too sweet'),(37,1635203944,1633742135,1633742135,'2021-10-25 23:19:04',0,'Not the best tea'),(46,1635285959,1632185629,1632185629,'2021-10-26 22:59:34',5,'Shot with sour gummy made it worse'),(47,1635289804,1635289739,1635289739,'2021-10-26 23:10:04',3,'Its beer'),(48,1635285959,1633742135,1633742135,'2021-10-26 23:24:49',7,''),(49,1635291609,1635289739,1635289739,'2021-10-26 23:40:09',4,''),(50,1635285959,1633742135,1633742135,'2021-10-26 23:49:24',8,''),(51,1635285959,1633742135,1633742135,'2021-10-27 00:14:57',8,''),(52,1635289804,1635289739,1635289739,'2021-10-27 00:20:10',3,''),(53,1635285959,1633742135,1633742135,'2021-10-27 00:38:08',8,''),(126,1635374525,1633742135,1633742135,'2021-11-02 21:44:22',8,'Gives me the runs'),(55,1635371847,1633742135,1633742135,'2021-10-27 21:57:27',9,''),(56,2,1632185629,1632185629,'2021-10-27 21:57:55',9,''),(57,1635374525,1635289739,1635289739,'2021-10-27 22:42:05',4,''),(58,2,1632185629,1632185629,'2021-10-27 22:45:09',9,''),(59,1635444208,1632185629,1632185629,'2021-10-28 18:03:28',10,'Perfect fall drink'),(60,1635453237,1632185629,1632185629,'2021-10-28 20:33:57',5,'Tasty but very strong'),(61,1635457394,1633742135,1633742135,'2021-10-28 21:43:14',7,''),(62,8,1635289739,1635289739,'2021-10-28 22:31:15',0,''),(63,1635289804,1635289739,1635289739,'2021-10-28 22:31:30',0,''),(64,1635291609,1635289739,1635289739,'2021-10-28 23:00:35',0,''),(65,1635467100,1635289739,1635289739,'2021-10-29 00:25:00',8,''),(66,1635272194,1632185629,1632185629,'2021-10-29 13:55:34',8,'Not very sweet compared to other mochas. Which in my opinion makes it better'),(67,1635540324,1633742135,1633742135,'2021-10-29 20:45:24',9,''),(68,1635549338,1632185629,1632185629,'2021-10-29 23:15:38',6,'Better with lime'),(69,1635549818,1633742135,1633742135,'2021-10-29 23:23:38',10,''),(70,1635617654,1632185629,1632185629,'2021-10-30 18:14:14',10,'So smooth and delicious'),(71,1635617654,1633742135,1633742135,'2021-10-30 18:14:53',10,'The best'),(72,1635617654,1633742135,1633742135,'2021-10-30 18:17:52',10,'The best'),(73,1635617654,1632185629,1632185629,'2021-10-30 18:17:57',10,''),(74,1635617654,1635617764,1635617764,'2021-10-30 18:18:13',7,''),(75,1635619315,1635617764,1635617764,'2021-10-30 18:41:55',9,''),(76,1635619531,1632185629,1632185629,'2021-10-30 18:45:31',7,'Doesnt mix very well'),(77,1635617654,1632185629,1632185629,'2021-10-30 20:35:13',0,''),(78,1635617654,1633742135,1633742135,'2021-10-30 20:35:19',10,''),(79,1635626467,1635617764,1635617764,'2021-10-30 20:41:07',6,''),(80,1635626572,1633742135,1633742135,'2021-10-30 20:42:52',0,''),(81,1635619315,1632185629,1632185629,'2021-10-30 20:45:45',5,'Too sweet'),(82,1635628197,1635617764,1635617764,'2021-10-30 21:09:57',9,'Good'),(83,1635619315,1635617764,1635617764,'2021-10-30 21:14:05',9,''),(84,1,1632185629,1632185629,'2021-10-30 21:24:11',0,''),(85,1635629150,1632185629,1632185629,'2021-10-30 21:25:50',5,''),(86,1635629981,1633742135,1633742135,'2021-10-30 21:39:41',10,'So good'),(87,1635630116,1635617764,1635617764,'2021-10-30 21:41:56',8,'Good'),(88,1635630116,1635617764,1635617764,'2021-10-30 21:43:29',8,''),(89,1635630116,1632185629,1632185629,'2021-10-30 21:54:07',0,''),(90,1635629981,1635617764,1635617764,'2021-10-30 22:08:04',8,''),(91,1635632437,1632185629,1632185629,'2021-10-30 22:20:37',4,''),(92,8,1632185629,1632185629,'2021-10-30 23:21:49',0,''),(93,1635638102,1635617764,1635617764,'2021-10-30 23:55:02',7,''),(94,1635630116,1632185629,1632185629,'2021-10-31 00:01:52',0,''),(95,1635629981,1635617764,1635617764,'2021-10-31 00:02:44',9,''),(96,1635629981,1635617764,1635617764,'2021-10-31 00:03:24',9,''),(97,1635639255,1633742135,1633742135,'2021-10-31 00:14:15',8,''),(98,1635617654,1632185629,1632185629,'2021-10-31 00:16:42',10,''),(99,1635617654,1633742135,1633742135,'2021-10-31 00:16:53',10,''),(100,1635617654,1635617764,1635617764,'2021-10-31 00:18:13',8,''),(101,1635632437,1635639508,1635639508,'2021-10-31 00:19:28',0,''),(102,1635632437,1635639508,1635639508,'2021-10-31 00:20:36',0,''),(103,1635632437,1635639508,1635639508,'2021-10-31 00:20:49',0,''),(104,1635632437,1635639508,1635639508,'2021-10-31 00:21:08',0,''),(105,1635632437,1635639508,1635639508,'2021-10-31 00:21:23',0,''),(106,1635374525,1635639508,1635639508,'2021-10-31 00:22:10',0,''),(107,1635629981,1635639508,1635639508,'2021-10-31 00:22:24',0,''),(108,1635629981,1635639508,1635639508,'2021-10-31 00:22:36',0,''),(109,1635617654,1635639508,1635639508,'2021-10-31 00:22:47',0,''),(110,1635626572,1632185629,1632185629,'2021-10-31 01:02:42',0,''),(111,1635644198,1633742135,1633742135,'2021-10-31 01:36:38',7,''),(112,1635632437,1632185629,1632185629,'2021-10-31 01:48:34',0,''),(113,1635626572,1632185629,1632185629,'2021-10-31 02:08:58',0,''),(114,1635626572,1633742135,1633742135,'2021-10-31 19:05:58',3,''),(125,12,1632185629,1632185629,'2021-11-01 22:26:31',0,''),(124,12,1633742135,1633742135,'2021-11-01 22:26:17',7,''),(123,12,1632185629,1632185629,'2021-11-01 22:01:10',8,''),(122,1635444208,1633742135,1633742135,'2021-11-01 21:59:42',10,''),(127,1,1632185629,1632185629,'2021-11-02 22:30:02',0,''),(128,1635968596,1634216328,1634216328,'2021-11-03 19:43:16',10,'Drink it'),(129,1635968596,1634216328,1634216328,'2021-11-03 19:44:01',10,''),(130,1,1632185629,1632185629,'2021-11-03 22:01:36',0,''),(131,1635626572,1633742135,1633742135,'2021-11-03 22:20:23',3,''),(132,1635980369,1634216328,1634216328,'2021-11-03 22:59:29',10,'Medical Purposes'),(133,1635626572,1633742135,1633742135,'2021-11-03 23:08:28',10,''),(134,1635983515,1632185629,1632185629,'2021-11-03 23:51:55',9,''),(135,1635444208,1632185629,1632185629,'2021-11-04 23:40:17',9,''),(136,1636069233,1633742135,1633742135,'2021-11-04 23:40:33',10,'Good drink'),(137,1636069233,1632185629,1632185629,'2021-11-04 23:43:44',0,''),(138,1636069233,1633742135,1633742135,'2021-11-04 23:45:30',10,''),(139,1636142526,1632185629,1632185629,'2021-11-05 20:02:07',10,''),(140,1636142526,1632185629,1632185629,'2021-11-05 20:02:15',0,''),(141,1636142748,1633742135,1633742135,'2021-11-05 20:05:48',2,''),(191,2,1632185629,1632185629,'2021-11-10 00:00:52',0,''),(143,1635626572,1633742135,1633742135,'2021-11-05 21:40:12',10,'Good'),(144,12,1632185629,1632185629,'2021-11-05 22:11:57',0,''),(145,1635285959,1633742135,1633742135,'2021-11-05 22:12:10',8,''),(146,1635285959,1633742135,1633742135,'2021-11-05 22:24:54',6,''),(147,1635626572,1632185629,1632185629,'2021-11-05 22:38:17',0,''),(148,1635626572,1633742135,1633742135,'2021-11-05 23:37:46',3,''),(149,1635619315,1635617764,1635617764,'2021-11-06 00:26:27',7,''),(150,1635632437,1635617764,1635617764,'2021-11-06 01:18:52',5,''),(151,1636165827,1635617764,1635617764,'2021-11-06 02:30:27',7,''),(152,1635638102,1635617764,1635617764,'2021-11-06 03:10:51',8,''),(153,1635629981,1635617764,1635617764,'2021-11-06 03:13:54',9,''),(154,1635629981,1635617764,1635617764,'2021-11-06 03:14:46',8,''),(155,1636222039,1633742135,1633742135,'2021-11-06 18:07:19',10,'So good'),(156,1636222039,1633742135,1633742135,'2021-11-06 18:07:30',10,''),(157,1636222039,1633742135,1633742135,'2021-11-06 18:07:53',10,''),(158,1636229331,1632185629,1632185629,'2021-11-06 20:08:51',8,'Tastes just like barques'),(159,1636229331,1633742135,1633742135,'2021-11-06 20:09:20',9,''),(160,1635617654,1632185629,1632185629,'2021-11-06 20:12:51',0,''),(161,1635617654,1633742135,1633742135,'2021-11-06 20:13:05',10,''),(162,1636229747,1632185629,1632185629,'2021-11-06 20:15:47',9,''),(163,1635617654,1633742135,1633742135,'2021-11-06 20:16:03',10,''),(164,1,1633742135,1633742135,'2021-11-06 20:44:58',10,''),(165,1636236626,1633742135,1633742135,'2021-11-06 22:10:26',7,''),(166,1,1632185629,1632185629,'2021-11-06 22:25:33',0,''),(167,1635626572,1633742135,1633742135,'2021-11-06 23:52:10',8,''),(168,1636253492,1635617764,1635617764,'2021-11-07 02:51:32',8,''),(169,1636253492,1635617764,1635617764,'2021-11-07 03:28:39',8,''),(170,1635619315,1635617764,1635617764,'2021-11-07 05:07:27',9,''),(171,1636253492,1635617764,1635617764,'2021-11-07 21:12:23',8,''),(172,2,1632185629,1632185629,'2021-11-07 22:21:29',0,''),(173,1635626572,1633742135,1633742135,'2021-11-07 22:22:29',8,''),(174,1636324151,1635617764,1635617764,'2021-11-07 22:29:11',7,''),(175,1635619315,1635617764,1635617764,'2021-11-07 23:13:14',8,''),(176,1636324151,1635617764,1635617764,'2021-11-08 01:17:30',6,''),(177,1635629981,1635617764,1635617764,'2021-11-08 01:27:27',8,''),(178,1636337047,1635617764,1635617764,'2021-11-08 02:04:07',9,''),(179,1635632437,1635617764,1635617764,'2021-11-08 03:09:03',6,''),(180,1636342349,1635617764,1635617764,'2021-11-08 03:32:29',9,''),(181,1636342349,1635617764,1635617764,'2021-11-08 03:56:25',9,''),(182,1636342349,1635617764,1635617764,'2021-11-08 04:06:31',8,''),(183,1636342349,1635617764,1635617764,'2021-11-08 04:22:12',8,''),(193,1635626572,1633742135,1633742135,'2021-11-10 00:03:56',8,''),(192,1636229747,1632185629,1632185629,'2021-11-10 00:01:06',9,''),(195,1635626572,1633742135,1633742135,'2021-11-10 22:51:06',10,''),(196,3,1632185629,1632185629,'2021-11-10 22:55:00',0,''),(197,1636229331,1633742135,1633742135,'2021-11-11 00:16:01',10,'Hit the m spot'),(198,1636229331,1632185629,1632185629,'2021-11-11 00:16:03',8,'Tastes just like barques'),(199,1636229331,1632185629,1632185629,'2021-11-11 00:16:59',8,'Tastes just like barques'),(200,1636229331,1633742135,1633742135,'2021-11-11 00:17:21',10,'Hit the m spot'),(201,1,1632185629,1634159870,'2021-11-11 00:37:23',0,''),(202,1635617654,1633742135,1633742135,'2021-11-11 00:44:03',10,''),(203,1635617654,1632185629,1634159870,'2021-11-11 00:44:11',10,''),(204,1635617654,1633742135,1635286780,'2021-11-11 00:45:01',10,''),(205,1636591606,1633742135,1635286780,'2021-11-11 00:46:46',10,''),(206,13,1636481952,1636481996,'2021-11-11 00:56:32',0,'Yum!'),(207,1635285959,1632185629,1634159870,'2021-11-11 01:36:38',8,''),(208,13,1636481952,1636481996,'2021-11-11 01:36:40',7,''),(209,1635617654,1633742135,1635286780,'2021-11-11 01:51:09',10,''),(210,1635626572,1633742135,1635286780,'2021-11-11 01:51:45',8,'Kicks my ass just like I like'),(211,1636597491,1636481952,1636481996,'2021-11-11 02:24:51',2,''),(212,1635285959,1633742135,1633742135,'2021-11-11 23:46:40',3,''),(213,1636674451,1632185629,1632185629,'2021-11-11 23:47:31',0,''),(214,1635626572,1633742135,1633742135,'2021-11-11 23:47:35',2,''),(215,1636674451,1632185629,1632185629,'2021-11-11 23:47:40',0,''),(216,10,1632185629,1632185629,'2021-11-11 23:47:48',0,''),(217,1636674451,1633742135,1633742135,'2021-11-11 23:47:49',1,''),(218,10,1632185629,1632185629,'2021-11-11 23:47:54',0,''),(219,10,1632185629,1632185629,'2021-11-11 23:48:00',0,''),(220,1636229331,1632185629,1632185629,'2021-11-11 23:48:42',8,'Tastes just like barques'),(221,1636229331,1633742135,1633742135,'2021-11-12 00:35:43',10,''),(222,1636229331,1633742135,1633742135,'2021-11-12 00:45:45',9,''),(223,1636229331,1633742135,1633742135,'2021-11-12 00:57:31',9,''),(224,1636229331,1633742135,1633742135,'2021-11-12 00:57:38',9,''),(225,1636229331,1633742135,1633742135,'2021-11-12 01:00:54',9,''),(226,1636229331,1633742135,1633742135,'2021-11-12 01:01:54',9,''),(227,1636229331,1633742135,1633742135,'2021-11-12 01:03:39',10,''),(228,1636229331,1633742135,1633742135,'2021-11-12 01:05:23',10,''),(229,1635628197,1635617764,1635617764,'2021-11-13 00:05:00',7,''),(230,1636324151,1635617764,1635617764,'2021-11-13 01:06:18',7,''),(231,1636767091,1632185629,1632185629,'2021-11-13 01:31:32',9,'Tastes just like its name'),(232,1636771163,1635617764,1635617764,'2021-11-13 02:39:23',7,''),(233,1635629150,1635617764,1635617764,'2021-11-13 02:44:57',8,''),(234,1636324151,1635617764,1635617764,'2021-11-13 04:16:44',5,''),(235,1636324151,1635617764,1635617764,'2021-11-13 05:31:47',7,''),(236,1636830877,1633742135,1633742135,'2021-11-13 19:14:37',10,''),(237,1636767091,1632185629,1632185629,'2021-11-13 19:16:15',9,'Tastes just like its name'),(238,2,1633742135,1633742135,'2021-11-13 19:58:09',10,''),(239,1635626572,1632185629,1632185629,'2021-11-13 22:20:11',0,''),(240,1636324151,1635617764,1635617764,'2021-11-13 22:40:49',9,''),(241,2,1632185629,1632185629,'2021-11-13 22:56:58',0,''),(242,1635619315,1635617764,1635617764,'2021-11-13 23:49:41',7,''),(243,1636830877,1633742135,1633742135,'2021-11-14 01:01:51',10,''),(244,1636324151,1635617764,1635617764,'2021-11-14 02:38:52',7,''),(245,1637021441,1632185629,1632185629,'2021-11-16 00:10:41',8,''),(246,1637105076,1634216328,1634216328,'2021-11-16 23:24:36',10,'Scotch Ale at Taphouse'),(247,1637105169,1634216328,1634216328,'2021-11-16 23:26:09',10,'At Taphouse'),(248,1637107789,1634216328,1634216328,'2021-11-17 00:09:49',10,'American Stout at Taphouse'),(249,1636229747,1633742135,1633742135,'2021-11-18 00:04:14',10,''),(250,1636229747,1633742135,1633742135,'2021-11-18 00:17:47',10,''),(251,1635453237,1633742135,1635286780,'2021-11-18 00:37:07',6,''),(252,10,1632185629,1632185629,'2021-11-18 02:34:48',0,''),(253,10,1632185629,1632185629,'2021-11-18 02:34:54',0,''),(254,10,1632185629,1632185629,'2021-11-18 02:35:07',0,''),(255,10,1632185629,1632185629,'2021-11-18 02:35:12',0,''),(256,1637202988,1632185629,1634159870,'2021-11-18 02:36:28',0,''),(257,1636324151,1635617764,1635617764,'2021-11-19 00:30:08',6,''),(258,1636337047,1635617764,1635617764,'2021-11-19 01:35:33',0,''),(259,1636324151,1635617764,1635617764,'2021-11-19 02:08:10',6,''),(260,1636771163,1635617764,1635617764,'2021-11-19 03:33:39',8,''),(261,1636324151,1635617764,1635617764,'2021-11-19 07:23:59',6,''),(262,1636771163,1635617764,1635617764,'2021-11-19 23:46:06',8,''),(263,1637366526,1632185629,1632185629,'2021-11-20 00:02:07',9,'Very good'),(264,1637366597,1633742135,1633742135,'2021-11-20 00:03:17',10,''),(265,1635632437,1635617764,1635617764,'2021-11-20 01:39:45',6,''),(266,1637107789,1632185629,1632185629,'2021-11-20 01:59:20',7,'Like a bourbon and Guinness'),(267,1637374429,1637373889,1637373889,'2021-11-20 02:13:49',10,'Tallgrass Taphouse ‘Secret Menu’'),(268,1637105076,1634216328,1634216328,'2021-11-20 02:14:56',10,''),(269,1637374652,1637373889,1637373889,'2021-11-20 02:17:32',6,'Tallgrass Taphouse Cocktail'),(270,1636767091,1632185629,1632185629,'2021-11-20 20:07:03',0,''),(271,1636767091,1633742135,1633742135,'2021-11-20 23:36:21',10,''),(272,1636591606,1633742135,1633742135,'2021-11-20 23:36:46',10,''),(273,1635632437,1635617764,1635617764,'2021-11-21 02:53:11',5,''),(274,1637466434,1635617764,1635617764,'2021-11-21 03:47:14',9,''),(275,1637466434,1635617764,1635617764,'2021-11-21 04:32:28',8,''),(276,1636229747,1633742135,1633742135,'2021-11-21 20:18:44',10,''),(277,1635617654,1633742135,1633742135,'2021-11-21 21:29:16',10,''),(278,1637538870,1633742135,1633742135,'2021-11-21 23:54:30',8,''),(279,1637538870,1633742135,1633742135,'2021-11-21 23:54:36',8,''),(280,1636253492,1635617764,1635617764,'2021-11-22 01:18:01',8,''),(281,1636830877,1633742135,1633742135,'2021-11-22 22:52:27',10,''),(282,1635626572,1632185629,1632185629,'2021-11-22 22:52:36',0,''),(283,1637105076,1634216328,1634216328,'2021-11-23 22:05:52',0,''),(284,1637107789,1634216328,1634216328,'2021-11-23 22:06:09',0,''),(285,1637105169,1634216328,1634216328,'2021-11-23 22:34:32',0,''),(286,1637105169,1634216328,1634216328,'2021-11-23 22:34:33',0,''),(287,1635617654,1633742135,1633742135,'2021-11-24 00:02:00',10,''),(288,1635617654,1633742135,1633742135,'2021-11-24 00:02:48',10,''),(289,1637718809,1633742135,1633742135,'2021-11-24 01:53:29',10,''),(290,1636253492,1635617764,1635617764,'2021-11-24 05:17:58',8,''),(291,1636253492,1635617764,1635617764,'2021-11-24 05:18:08',8,''),(292,1637718809,1633742135,1635286780,'2021-11-25 00:33:58',10,''),(293,2,1632185629,1634159870,'2021-11-25 00:36:48',0,''),(294,1636069233,1633742135,1635286780,'2021-11-25 01:52:17',10,''),(295,1637805342,1636481952,1636481996,'2021-11-25 01:55:42',8,''),(296,1637805389,1632185629,1634159870,'2021-11-25 01:56:29',0,''),(297,1636253492,1635617764,1635617764,'2021-11-26 00:14:43',8,''),(298,1637891521,1635617764,1635617764,'2021-11-26 01:52:02',5,''),(299,1637891521,1635617764,1635617764,'2021-11-26 04:19:11',8,''),(300,1637976950,1635617764,1635617764,'2021-11-27 01:35:51',8,''),(301,1637985079,1635617764,1635617764,'2021-11-27 03:51:19',9,''),(302,18,1632185629,1634159870,'2021-12-02 00:37:41',0,''),(303,18,1633742135,1635286780,'2021-12-02 01:16:29',9,''),(304,1637805342,1636481952,1636481996,'2021-12-02 01:17:25',8,''),(305,18,1633742135,1635286780,'2021-12-02 02:44:27',9,''),(306,1637805342,1636481952,1636481996,'2021-12-02 03:08:57',8,''),(307,1638414675,1633742135,1635286780,'2021-12-02 03:11:16',9,''),(308,1636771163,1635617764,1635617764,'2021-12-04 03:00:17',8,''),(309,1637718809,1633742135,1635286780,'2021-12-09 00:34:11',2,''),(310,1635626572,1632185629,1634159870,'2021-12-09 00:34:21',0,''),(311,13,1636481952,1636481996,'2021-12-09 00:37:39',7,''),(312,12,1632185629,1634159870,'2021-12-09 00:42:51',0,''),(313,13,1636481952,1636481996,'2021-12-09 00:43:04',8,''),(314,1639010604,1633742135,1635286780,'2021-12-09 00:43:24',3,''),(315,1637805342,1636481952,1636481996,'2021-12-09 02:15:17',9,''),(316,13,1636481952,1636481996,'2021-12-23 00:48:56',7,''),(317,13,1636481952,1636481996,'2021-12-23 01:36:36',8,''),(318,8,1632185629,1640374271,'2021-12-24 20:05:20',0,''),(319,1640376534,1633742135,1640375236,'2021-12-24 20:08:54',7,''),(320,1640380460,1633742135,1640375236,'2021-12-24 21:14:20',8,''),(321,1640380696,1632185629,1640374271,'2021-12-24 21:18:16',8,'Not bad'),(322,1635289804,1635289739,1640374647,'2021-12-24 21:42:05',0,''),(323,1640376534,1633742135,1640375236,'2021-12-24 21:43:13',10,''),(324,1635289804,1635289739,1640374647,'2021-12-24 22:08:45',0,''),(325,8,1632185629,1640374271,'2021-12-24 22:20:44',0,''),(326,1637985079,1635617764,1640374331,'2021-12-24 22:28:15',9,''),(327,1640380460,1633742135,1640375236,'2021-12-24 22:43:13',8,''),(328,2,1640372531,1640372733,'2021-12-24 23:09:32',0,''),(329,1640380460,1633742135,1640375236,'2021-12-24 23:18:00',8,''),(330,2,1640372531,1640372733,'2021-12-24 23:18:13',0,'Eat it fuckers!'),(331,1640387941,1635289739,1640374647,'2021-12-24 23:19:01',0,''),(332,1640380696,1632185629,1640374271,'2021-12-24 23:24:09',0,''),(333,1640387941,1635289739,1640374647,'2021-12-24 23:34:31',0,''),(334,1640389011,1632185629,1640374271,'2021-12-24 23:36:51',8,''),(335,1640380460,1633742135,1640375236,'2021-12-24 23:50:18',7,''),(336,1640389886,1635617764,1640374331,'2021-12-24 23:51:26',8,''),(337,1640391638,1632185629,1640374271,'2021-12-25 00:20:38',3,'Not very good'),(338,1640380696,1635617764,1640374331,'2021-12-25 00:39:02',8,''),(339,1640380460,1633742135,1640375236,'2021-12-25 00:50:07',7,''),(340,1640376534,1635617764,1640374331,'2021-12-25 01:42:26',9,''),(341,1640380460,1633742135,1640375236,'2021-12-25 01:46:20',6,'Jacee is a bitch'),(342,1640389886,1635617764,1640374331,'2021-12-25 02:24:14',7,''),(343,2,1640372531,1640372733,'2021-12-25 02:30:05',0,''),(344,2,1640372531,1640372733,'2021-12-25 02:30:18',0,''),(345,1635289804,1635289739,1640374647,'2021-12-25 04:02:47',0,''),(346,1635289804,1635289739,1640374647,'2021-12-25 04:03:13',0,''),(347,1635291609,1640372531,1640372733,'2021-12-25 04:12:57',0,''),(348,1635291609,1640372531,1640372733,'2021-12-25 04:13:00',0,''),(349,1635549818,1640372531,1640372733,'2021-12-25 04:13:21',0,''),(350,1635549818,1640372531,1640372733,'2021-12-25 04:32:13',0,''),(351,1635549818,1640372531,1640372733,'2021-12-25 05:02:53',0,''),(352,1640439796,1632185629,1640374271,'2021-12-25 13:43:17',0,''),(353,1635626572,1632185629,1640374271,'2021-12-25 16:16:55',0,''),(354,1640449947,1634216328,1640449496,'2021-12-25 16:32:27',10,'Breakfast'),(355,1640380460,1633742135,1640375236,'2021-12-25 16:32:50',8,''),(356,1640449947,1634216328,1640449496,'2021-12-25 16:32:59',10,'Yum'),(357,1640457646,1632185629,1640374271,'2021-12-25 18:40:46',8,''),(358,1640457721,1633742135,1640375236,'2021-12-25 18:42:01',2,''),(359,1640457908,1634216328,1640449496,'2021-12-25 18:45:08',10,'Yes'),(360,1640387941,1635289739,1640374647,'2021-12-25 19:06:14',0,''),(361,8,1632185629,1640374271,'2021-12-25 19:15:42',0,''),(362,1640380460,1635617764,1640374331,'2021-12-25 19:42:25',7,''),(363,8,1632185629,1640374271,'2021-12-25 19:57:19',0,''),(364,1640462346,1633742135,1640375236,'2021-12-25 19:59:06',2,''),(365,8,1635289739,1640374647,'2021-12-25 20:06:41',0,''),(366,1640462346,1633742135,1640375236,'2021-12-25 21:00:55',4,''),(367,8,1632185629,1640374271,'2021-12-25 21:04:04',0,''),(368,1640457908,1634216328,1640449496,'2021-12-25 21:08:38',0,''),(369,1640466774,1633742135,1640375236,'2021-12-25 21:12:54',10,''),(370,1640466918,1633742135,1640375236,'2021-12-25 21:15:19',10,''),(371,1640466921,1633742135,1640375236,'2021-12-25 21:15:21',10,''),(372,1640466918,1632185629,1640374271,'2021-12-25 21:15:33',0,''),(373,1640467195,1635617764,1640374331,'2021-12-25 21:19:55',9,''),(374,1640457908,1634216328,1640449496,'2021-12-25 21:36:31',0,''),(375,1640467195,1635617764,1640374331,'2021-12-25 21:56:03',8,''),(376,8,1632185629,1640374271,'2021-12-25 22:19:58',0,''),(377,1635626572,1635617764,1640374331,'2021-12-25 23:07:57',9,''),(378,1640474037,1632185629,1640374271,'2021-12-25 23:13:57',9,''),(379,1640474037,1635289739,1640374647,'2021-12-25 23:31:55',0,''),(380,1640467195,1635617764,1640374331,'2021-12-25 23:56:26',9,''),(381,1640462346,1633742135,1640375236,'2021-12-26 00:38:27',2,''),(382,1640387941,1635289739,1640374647,'2021-12-26 00:48:42',0,''),(383,1640479738,1632185629,1640374271,'2021-12-26 00:48:58',7,''),(384,1640481863,1633742135,1640375236,'2021-12-26 01:24:23',10,''),(385,1635289804,1632185629,1640374271,'2021-12-26 01:39:14',0,''),(386,1635626572,1633742135,1640375236,'2021-12-26 02:15:35',10,''),(387,1640488966,1635617764,1640374331,'2021-12-26 03:22:46',7,''),(388,1640462346,1633742135,1640375236,'2021-12-26 03:29:48',4,''),(389,1640494034,1633742135,1640375236,'2021-12-26 04:47:14',5,''),(390,1640632143,1632185629,1632185629,'2021-12-27 19:09:03',9,'Very sweet'),(391,1640632228,1634216328,1634216328,'2021-12-27 19:10:28',8,'Wheat Ale'),(397,4,1632185629,1634159870,'2022-01-10 19:44:57',0,''),(398,1642034000,1632185629,1634159870,'2022-01-13 00:33:20',2,'Burns like fire'),(399,1643930679,1632185629,1632185629,'2022-02-03 23:24:39',2,''),(400,1644623887,1632185629,1632185629,'2022-02-11 23:58:07',0,''),(401,1644626217,1632185629,1632185629,'2022-02-12 00:36:57',0,''),(402,1644631509,1632185629,1632185629,'2022-02-12 02:05:09',0,''),(403,1644631509,1632185629,1632185629,'2022-02-12 04:24:46',0,''),(404,1640479738,1647110065,1647110065,'2022-03-12 18:35:56',0,''),(405,1647110168,1632185629,1647109749,'2022-03-12 18:36:08',5,''),(406,1647110237,1647110095,1647110095,'2022-03-12 18:37:17',10,'Soooooooo good!'),(407,1647110289,1633742135,1647109699,'2022-03-12 18:38:09',2,'Not made correctly '),(408,1647110393,1647110164,1647110164,'2022-03-12 18:39:54',0,''),(409,5,1632185629,1647109749,'2022-03-12 19:10:14',8,'Jameson whiskey'),(410,5,1647110065,1647110065,'2022-03-12 19:10:21',0,''),(411,5,1647110164,1647110164,'2022-03-12 19:10:59',0,''),(412,1644631509,1632185629,1647109749,'2022-03-12 19:35:20',0,''),(413,1647115233,0,0,'2022-03-12 20:00:34',8,'So good'),(414,5,1633742135,1647109699,'2022-03-12 20:01:22',7,''),(415,1640494034,1633742135,1647109699,'2022-03-12 20:02:01',10,''),(416,1647115233,1633742135,1647109699,'2022-03-12 20:02:23',9,''),(417,1647115419,1647110004,1647110004,'2022-03-12 20:03:39',10,''),(418,5,1647110004,1647110004,'2022-03-12 22:52:45',0,''),(419,5,1647110004,1647110004,'2022-03-12 22:52:47',0,'');
/*!40000 ALTER TABLE `UserHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `UserID` int(4) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Pin` int(4) NOT NULL,
  `Xp` int(50) NOT NULL DEFAULT '0',
  `Gender` varchar(255) DEFAULT NULL,
  `BirthDate` date DEFAULT NULL,
  `Weight` varchar(10) DEFAULT NULL,
  `Height` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1634216328,'Handsies',5059,0,NULL,NULL,NULL,NULL),(1633742135,'Jess',80085,0,NULL,NULL,NULL,NULL),(1632185629,'Devon',1225,0,NULL,NULL,NULL,NULL),(1635289739,'Trev',2446,0,NULL,NULL,NULL,NULL),(1635360868,'Trentontyhill',1234,0,NULL,NULL,NULL,NULL),(1635617764,'Jc',9600,0,NULL,NULL,NULL,NULL),(1635639508,'LauraLiquor',1210,0,NULL,NULL,NULL,NULL),(1636320886,'conradic',9975,0,NULL,NULL,NULL,NULL),(1636481952,'amechtle',3733,0,NULL,NULL,NULL,NULL),(1637373889,'Jnbrock',1994,0,NULL,NULL,NULL,NULL),(1640372531,'Triple Fister',102005,0,NULL,NULL,NULL,NULL),(1647110004,'MJackson',1988,0,NULL,NULL,NULL,NULL),(1647110065,'J-Rock',1020,0,NULL,NULL,NULL,NULL),(1647110095,'trentontyhill@gmail.com',1234,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'DrinkingLevels'
--
/*!50003 DROP PROCEDURE IF EXISTS `GetUserUsername` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dandersen`@`%` PROCEDURE `GetUserUsername`(IN `pUserID` VARCHAR(3200), OUT `pUsername` VARCHAR(3200))
    NO SQL
BEGIN
	select u.Username INTO pUsername 
	from DrinkingLevels.Users u
	where u.UserID = pUserID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetXp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`dandersen`@`%` PROCEDURE `GetXp`(IN profileID varchar(3200), IN userID varchar(3200), OUT xp varchar(3200))
BEGIN
	select sum(d.ABV) INTO xp 
	from DrinkingLevels.UserHistory uh 
	left join DrinkingLevels.Drinks d on uh.DrinkID = d.DrinkID 
	where uh.UserID = userID and uh.ProfileID = profileID;
	END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `DRINK_CHART`
--

/*!50001 DROP TABLE IF EXISTS `DRINK_CHART`*/;
/*!50001 DROP VIEW IF EXISTS `DRINK_CHART`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dandersen`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `DRINK_CHART` AS select `d`.`DrinkID` AS `DrinkID`,`d`.`DrinkName` AS `DrinkName`,`d`.`DrinkRecipe` AS `DrinkRecipe`,`d`.`ABV` AS `ABV`,`d`.`Type` AS `Type`,(`d`.`ABV` * 1) AS `12oz`,(`d`.`ABV` * 1.33) AS `16oz`,(`d`.`ABV` * 0.12) AS `Shot`,(`d`.`ABV` * 0.4) AS `5oz` from `Drinks` `d` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Profile_Details`
--

/*!50001 DROP TABLE IF EXISTS `Profile_Details`*/;
/*!50001 DROP VIEW IF EXISTS `Profile_Details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dandersen`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `Profile_Details` AS select `p`.`UserID` AS `UserID`,(select `u`.`Username` from `Users` `u` where (`u`.`UserID` = `p`.`UserID`)) AS `Username`,`p`.`ProfileID` AS `ProfileID`,`p`.`Name` AS `Name`,ifnull((select min(`Levels`.`LevelID`) from `Levels` where (`Levels`.`XpToLevel` > (select sum(`d`.`ABV`) from (`UserHistory` `uh` left join `Drinks` `d` on((`uh`.`DrinkID` = `d`.`DrinkID`))) where ((`uh`.`UserID` = `p`.`UserID`) and (`uh`.`ProfileID` = `p`.`ProfileID`))))),0) AS `Level`,ifnull(((select sum(`d`.`ABV`) from (`UserHistory` `uh` left join `Drinks` `d` on((`uh`.`DrinkID` = `d`.`DrinkID`))) where ((`uh`.`UserID` = `p`.`UserID`) and (`uh`.`ProfileID` = `p`.`ProfileID`))) - ifnull((select max(`Levels`.`XpToLevel`) from `Levels` where (`Levels`.`XpToLevel` < (select sum(`d`.`ABV`) from (`UserHistory` `uh` left join `Drinks` `d` on((`uh`.`DrinkID` = `d`.`DrinkID`))) where ((`uh`.`UserID` = `p`.`UserID`) and (`uh`.`ProfileID` = `p`.`ProfileID`))))),0)),0) AS `XP`,`p`.`Description` AS `Description`,`t`.`Title` AS `Title`,ifnull(((select min(`Levels`.`XpToLevel`) from `Levels` where (`Levels`.`XpToLevel` > (select sum(`d`.`ABV`) from (`UserHistory` `uh` left join `Drinks` `d` on((`uh`.`DrinkID` = `d`.`DrinkID`))) where ((`uh`.`UserID` = `p`.`UserID`) and (`uh`.`ProfileID` = `p`.`ProfileID`))))) - ifnull((select max(`Levels`.`XpToLevel`) from `Levels` where (`Levels`.`XpToLevel` < (select sum(`d`.`ABV`) from (`UserHistory` `uh` left join `Drinks` `d` on((`uh`.`DrinkID` = `d`.`DrinkID`))) where ((`uh`.`UserID` = `p`.`UserID`) and (`uh`.`ProfileID` = `p`.`ProfileID`))))),0)),0) AS `XpToLevel`,(select sum(`d`.`ABV`) from (`UserHistory` `uh` left join `Drinks` `d` on((`uh`.`DrinkID` = `d`.`DrinkID`))) where ((`uh`.`UserID` = `p`.`UserID`) and (`uh`.`ProfileID` = `p`.`ProfileID`))) AS `Actual_Total_Xp`,(select min(`Levels`.`XpToLevel`) from `Levels` where (`Levels`.`XpToLevel` > (select sum(`d`.`ABV`) from (`UserHistory` `uh` left join `Drinks` `d` on((`uh`.`DrinkID` = `d`.`DrinkID`))) where ((`uh`.`UserID` = `p`.`UserID`) and (`uh`.`ProfileID` = `p`.`ProfileID`))))) AS `Actual_Total_XpToLevel`,`p`.`Template` AS `Template`,`p`.`Avatar` AS `Avatar`,concat('{',`t`.`Category`,':',`t`.`Position`,'}') AS `ActiveTitle`,`p`.`UnlockedTitles` AS `UnlockedTitles` from (`Profiles` `p` left join `Titles` `t` on((`p`.`ActiveTitle` = concat('{',`t`.`Category`,':',`t`.`Position`,'}')))) order by `p`.`ProfileID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Profile_History`
--

/*!50001 DROP TABLE IF EXISTS `Profile_History`*/;
/*!50001 DROP VIEW IF EXISTS `Profile_History`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`dandersen`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `Profile_History` AS select `uh`.`RowID` AS `RowID`,`uh`.`ProfileID` AS `ProfileID`,`uh`.`DrinkID` AS `DrinkID`,`p`.`Name` AS `Name`,`d`.`DrinkName` AS `DrinkName`,`d`.`DrinkRecipe` AS `DrinkRecipe`,`d`.`Type` AS `Type`,`d`.`ABV` AS `ABV`,`uh`.`Timestamp` AS `Timestamp`,date_format(`uh`.`Timestamp`,'%m/%d/%y') AS `Timestamp_Date`,`uh`.`Rating` AS `Rating`,`uh`.`Notes` AS `Notes` from ((`UserHistory` `uh` left join `Drinks` `d` on((`d`.`DrinkID` = `uh`.`DrinkID`))) left join `Profiles` `p` on((`p`.`ProfileID` = `uh`.`ProfileID`))) order by `uh`.`Timestamp` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-11  8:41:00
